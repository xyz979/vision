import { useEffect } from "react";
import { useRoute } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { PersonalityType } from "@/components/profile/personality-type";
import { MediaHabits } from "@/components/profile/media-habits";
import { ContentPreferences } from "@/components/profile/content-preferences";
import { InsightsRecommendations } from "@/components/profile/insights-recommendations";
import { ActionSection } from "@/components/profile/action-section";
import { HeroSection } from "@/components/profile/hero-section";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";

export default function Profile() {
  const [match, params] = useRoute("/profile/:id");
  const profileId = params?.id;

  // Fetch profile data from API
  const { data: profile, isLoading, isError } = useQuery({
    queryKey: [`http://localhost:5000/api/profile/${profileId}`],
    enabled: !!profileId,
  });

  // Scroll to top when component mounts
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  if (isLoading) {
    return <ProfileSkeleton />;
  }

  if (isError || !profile) {
    return (
      <div className="container mx-auto px-4 py-12">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>
            Failed to load profile. This profile may not exist or there was an error retrieving the data.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div>
      <HeroSection profileId={profile.profileId} />
      
      <PersonalityType 
        personalityType={profile.personalityType}
        personalityDescription={profile.personalityDescription}
        personalityTags={profile.personalityTags || ["Media Consumer", "Digital User", "Content Explorer"]}
      />
      
      <MediaHabits 
        mediaTimeData={profile.mediaTimeData}
        deviceData={profile.deviceData}
      />
      
      <ContentPreferences 
        contentPreferences={profile.contentPreferences}
      />
      
      <InsightsRecommendations 
        insights={profile.insights}
        recommendations={profile.recommendations}
      />
      
      <ActionSection />
    </div>
  );
}

// Skeleton loader while profile is loading
function ProfileSkeleton() {
  return (
    <div>
      {/* Hero Section Skeleton */}
      <section className="py-12 md:py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <Skeleton className="h-8 w-40 mx-auto mb-6" />
            <Skeleton className="h-12 w-full max-w-2xl mx-auto mb-6" />
            <Skeleton className="h-6 w-full max-w-xl mx-auto mb-8" />
            <div className="flex justify-center">
              <Skeleton className="h-12 w-36 mr-4" />
              <Skeleton className="h-12 w-36" />
            </div>
          </div>
        </div>
      </section>

      {/* Personality Type Skeleton */}
      <section className="py-16 bg-neutral-100">
        <div className="container mx-auto px-4">
          <div className="max-w-5xl mx-auto">
            <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
              <div className="p-8 md:p-12">
                <div className="flex flex-col md:flex-row items-center md:items-start">
                  <Skeleton className="w-32 h-32 md:w-40 md:h-40 rounded-full flex-shrink-0 mb-6 md:mb-0" />
                  <div className="md:ml-8 w-full">
                    <Skeleton className="h-6 w-32 mb-4" />
                    <Skeleton className="h-10 w-full max-w-md mb-4" />
                    <Skeleton className="h-6 w-full max-w-lg mb-6" />
                    <div className="flex flex-wrap gap-2">
                      <Skeleton className="h-6 w-24" />
                      <Skeleton className="h-6 w-24" />
                      <Skeleton className="h-6 w-24" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Media Habits Skeleton */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-5xl mx-auto">
            <Skeleton className="h-10 w-64 mx-auto mb-3" />
            <Skeleton className="h-6 w-full max-w-xl mx-auto mb-12" />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-neutral-100 rounded-xl p-6 shadow-sm">
                <Skeleton className="h-8 w-48 mb-8" />
                <div className="space-y-6">
                  {[1, 2, 3, 4].map(i => (
                    <div key={i} className="mb-4">
                      <div className="flex justify-between mb-2">
                        <Skeleton className="h-6 w-32" />
                        <Skeleton className="h-6 w-12" />
                      </div>
                      <Skeleton className="h-3 w-full rounded-full" />
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="bg-neutral-100 rounded-xl p-6 shadow-sm">
                <Skeleton className="h-8 w-48 mb-8" />
                <div className="grid grid-cols-2 gap-4">
                  {[1, 2, 3, 4].map(i => (
                    <div key={i} className="bg-white p-4 rounded-lg shadow-sm flex items-center">
                      <Skeleton className="w-12 h-12 rounded-full" />
                      <div className="ml-3 flex-grow">
                        <Skeleton className="h-5 w-24 mb-1" />
                        <Skeleton className="h-4 w-20" />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
