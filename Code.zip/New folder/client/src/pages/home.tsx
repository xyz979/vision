import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Eye } from "lucide-react";

export default function Home() {
  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section className="py-20 md:py-32 bg-gradient-to-b from-white to-neutral-100">
        <div className="container mx-auto px-4">
          <div className="max-w-5xl mx-auto text-center">
            <div className="inline-block px-3 py-1 rounded-full bg-primary-light/10 text-primary-dark font-medium text-sm mb-6">
              Discover Your Media Personality
            </div>
            <h1 className="text-4xl md:text-6xl font-display font-bold text-neutral-900 mb-6">
              Understand Your Digital Media Consumption
            </h1>
            <p className="text-xl text-neutral-600 mb-10 max-w-3xl mx-auto">
              MediaVision analyzes your media habits and preferences to create a personalized profile, 
              helping you gain insights into your digital consumption patterns.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button
                className="px-8 py-4 bg-primary text-white font-medium rounded-lg shadow-lg hover:bg-primary-dark transition-colors text-lg"
                onClick={() => window.location.href = "https://mediavision.paperform.co"}
              >
                Take the Survey
              </Button>
              <a href="#how-it-works">
                <Button 
                  variant="outline"
                  className="px-8 py-4 bg-white text-primary border border-primary font-medium rounded-lg hover:bg-primary/5 transition-colors text-lg"
                >
                  Learn More
                </Button>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section id="how-it-works" className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-display font-bold text-neutral-900 mb-3 text-center">
            How MediaVision Works
          </h2>
          <p className="text-neutral-600 mb-16 text-center max-w-3xl mx-auto">
            Our process is simple, yet powerful in providing you meaningful insights about your media consumption.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10 max-w-5xl mx-auto">
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center text-primary mx-auto mb-4">
                <span className="text-2xl font-bold">1</span>
              </div>
              <h3 className="text-xl font-display font-semibold mb-3">Take the Survey</h3>
              <p className="text-neutral-600">
                Complete our comprehensive survey about your media consumption habits and preferences.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-secondary/10 flex items-center justify-center text-secondary mx-auto mb-4">
                <span className="text-2xl font-bold">2</span>
              </div>
              <h3 className="text-xl font-display font-semibold mb-3">Get Analyzed</h3>
              <p className="text-neutral-600">
                Our algorithm processes your responses to create a personalized media profile.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-accent/10 flex items-center justify-center text-accent mx-auto mb-4">
                <span className="text-2xl font-bold">3</span>
              </div>
              <h3 className="text-xl font-display font-semibold mb-3">Receive Insights</h3>
              <p className="text-neutral-600">
                View your personalized profile with media habits, preferences, and tailored recommendations.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-neutral-100">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto bg-gradient-to-r from-primary to-accent rounded-2xl shadow-lg overflow-hidden">
            <div className="p-12 text-white text-center">
              <div className="mx-auto w-20 h-20 rounded-full bg-white/20 flex items-center justify-center mb-6">
                <Eye className="w-10 h-10 text-white" />
              </div>
              <h2 className="text-3xl md:text-4xl font-display font-bold mb-4">Ready to Discover Your Media Personality?</h2>
              <p className="text-xl mb-8 max-w-2xl mx-auto">
                Take our survey and get personalized insights about your media consumption habits and preferences.
              </p>
              <Button
                className="px-8 py-4 bg-white text-primary font-medium rounded-lg shadow-lg hover:bg-neutral-100 transition-colors text-lg"
                onClick={() => window.location.href = "https://mediavision.paperform.co"}
              >
                Start the Survey
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
