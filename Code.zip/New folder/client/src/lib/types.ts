// Media Profile related types
export interface MediaTimeDataItem {
  name: string;
  percentage: number;
  color: string;
}

export interface DeviceDataItem {
  name: string;
  percentage: number;
  icon: string;
  color: string;
}

export interface ContentPreference {
  type: string;
  icon: string;
  color: string;
  colorLight: string;
  favoriteGenres: string[];
  habits: string;
  insight: string;
}

export interface Insight {
  title: string;
  description: string;
  icon: string;
  color: string;
}

export interface Recommendation {
  category: string;
  items: string[];
}

export interface MediaProfileData {
  personalityType: string;
  personalityDescription: string;
  personalityTags: string[];
  mediaTimeData: MediaTimeDataItem[];
  deviceData: DeviceDataItem[];
  contentPreferences: ContentPreference[];
  insights: Insight[];
  recommendations: Recommendation[];
}

// Form submission types
export interface EmailSubscription {
  email: string;
}
