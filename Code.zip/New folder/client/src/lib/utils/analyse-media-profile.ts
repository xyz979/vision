import { MediaProfileData } from "../types";

// Personality types based on media consumption patterns
const personalityTypes = [
  {
    type: "The Cinephile Explorer",
    description: "You have a deep appreciation for visual storytelling and seek out diverse film experiences across genres and cultures. You value artistic expression and often discover hidden gems others might miss.",
    tags: ["Film Enthusiast", "Visual Learner", "Cultural Explorer"],
    mediaConditions: (data: any) => data.film_preference === "artistic" || data.viewing_frequency === "high"
  },
  {
    type: "The Digital Omnivore",
    description: "You consume a wide variety of media across multiple platforms with ease. You're comfortable switching between different types of content and devices, making you highly adaptable in the digital landscape.",
    tags: ["Multi-Platform User", "Content Diverse", "Tech Savvy"],
    mediaConditions: (data: any) => data.device_count > 3 || data.platform_diversity === "high"
  },
  {
    type: "The Thoughtful Analyst",
    description: "You approach media with a critical and analytical mindset, often seeking content that challenges your perspective or provides deep insights. You value substance over style in your media choices.",
    tags: ["Critical Thinker", "Knowledge Seeker", "Detail-Oriented"],
    mediaConditions: (data: any) => data.content_preference === "informative" || data.documentary_interest === "high"
  },
  {
    type: "The Social Media Navigator",
    description: "You have a natural talent for finding and curating social media content. You understand platform algorithms and community dynamics, making you effective at building digital connections.",
    tags: ["Trend Spotter", "Community Builder", "Digital Networker"],
    mediaConditions: (data: any) => data.social_media_usage === "high" || data.content_creation === "active"
  },
  {
    type: "The Immersive Enthusiast",
    description: "You seek deeply engaging, immersive experiences in your media consumption. Whether through gaming, VR, or binge-worthy series, you value content that fully captures your attention and imagination.",
    tags: ["Deep Engager", "Experience Seeker", "Focused Consumer"],
    mediaConditions: (data: any) => data.gaming_frequency === "high" || data.binge_watching === "frequent"
  }
];

// Default media profile to use when survey data doesn't have enough information
const defaultMediaProfile: MediaProfileData = {
  personalityType: "The Media Balanced Consumer",
  personalityDescription: "You have a balanced approach to media consumption, enjoying a variety of content types without being dominated by any single medium. You're selective about what you consume and maintain healthy boundaries with technology.",
  personalityTags: ["Balanced Consumer", "Selective Viewer", "Mindful User"],
  mediaTimeData: [
    { name: "Streaming Video", percentage: 30, color: "hsl(var(--primary))" },
    { name: "Social Media", percentage: 25, color: "hsl(var(--secondary))" },
    { name: "Music", percentage: 20, color: "hsl(var(--accent))" },
    { name: "Gaming", percentage: 15, color: "hsl(var(--purple-500))" },
    { name: "Reading", percentage: 10, color: "hsl(var(--green-500))" }
  ],
  deviceData: [
    { name: "Smartphone", percentage: 40, icon: "smartphone", color: "hsl(var(--primary))" },
    { name: "Laptop", percentage: 30, icon: "laptop", color: "hsl(var(--secondary))" },
    { name: "Smart TV", percentage: 20, icon: "tv", color: "hsl(var(--accent))" },
    { name: "Tablet", percentage: 10, icon: "tablet", color: "hsl(var(--purple-500))" }
  ],
  contentPreferences: [
    {
      type: "Film & TV",
      icon: "film",
      color: "hsl(var(--primary))",
      colorLight: "hsl(var(--primary) / 0.1)",
      favoriteGenres: ["Drama", "Documentary", "Comedy"],
      habits: "You enjoy a mix of mainstream and independent content, typically watching a few episodes at a time.",
      insight: "You appreciate quality production and storytelling in your viewing choices."
    },
    {
      type: "Music",
      icon: "music",
      color: "hsl(var(--secondary))",
      colorLight: "hsl(var(--secondary) / 0.1)",
      favoriteGenres: ["Pop", "Rock", "Indie"],
      habits: "You listen primarily during commutes and while working, with a mix of playlists and albums.",
      insight: "You use music both for enjoyment and as a productivity tool."
    },
    {
      type: "Social Media",
      icon: "share",
      color: "hsl(var(--accent))",
      colorLight: "hsl(var(--accent) / 0.1)",
      favoriteGenres: ["Instagram", "Twitter", "YouTube"],
      habits: "You check platforms several times daily but try to limit extended scrolling sessions.",
      insight: "You're more of a content consumer than creator, generally following friends and interests."
    }
  ],
  insights: [
    {
      title: "Balanced Media Diet",
      description: "You maintain a healthy balance across different media types, avoiding over-reliance on any single platform. This approach gives you a well-rounded perspective and prevents digital burnout.",
      icon: "scale",
      color: "hsl(var(--primary))"
    },
    {
      title: "Selective Consumption",
      description: "Rather than consuming content indiscriminately, you tend to be intentional about your choices. This selective approach leads to more meaningful and satisfying media experiences.",
      icon: "filter",
      color: "hsl(var(--secondary))"
    },
    {
      title: "Digital Boundaries",
      description: "You've developed reasonable boundaries with technology, allowing you to enjoy digital media without letting it dominate your life. This balanced relationship with technology is increasingly rare.",
      icon: "shield",
      color: "hsl(var(--accent))"
    },
    {
      title: "Diverse Interests",
      description: "Your media choices reflect a curiosity about various topics and genres. This intellectual openness exposes you to different perspectives and enriches your understanding of the world.",
      icon: "compass",
      color: "hsl(var(--purple-500))"
    }
  ],
  recommendations: [
    {
      category: "Films & TV",
      items: [
        "The Good Place (thoughtful comedy)",
        "Minari (family drama)",
        "Chef's Table (documentary series)"
      ]
    },
    {
      category: "Music",
      items: [
        "Big Thief (indie folk)",
        "Anderson .Paak (R&B/hip-hop)",
        "Khruangbin (psychedelic funk)"
      ]
    },
    {
      category: "Podcasts",
      items: [
        "99% Invisible (design)",
        "This American Life (storytelling)",
        "Freakonomics (economics)"
      ]
    }
  ]
};

// Analyze survey data and generate media personality profile
export function analyzeMediaProfile(surveyData: any): MediaProfileData {
  // In a real application, this would contain sophisticated analysis 
  // based on the survey responses. For now, we'll return the default profile
  // or select one based on basic patterns.
  
  // Determine personality type based on survey data
  // Find the first matching personality type or use default
  const matchedPersonality = personalityTypes.find(profile => {
    try {
      return profile.mediaConditions(surveyData);
    } catch (error) {
      // If data doesn't have expected fields
      return false;
    }
  });
  
  if (matchedPersonality) {
    return {
      ...defaultMediaProfile,
      personalityType: matchedPersonality.type,
      personalityDescription: matchedPersonality.description,
      personalityTags: matchedPersonality.tags
    };
  }
  
  return defaultMediaProfile;
}
