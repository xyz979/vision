import { DeviceDataItem } from "@/lib/types";
import { Smartphone, Laptop, Tv, Tablet } from "lucide-react";

interface DeviceUsageChartProps {
  data: DeviceDataItem[];
}

// Map of device names to icons
const deviceIcons = {
  smartphone: Smartphone,
  laptop: Laptop,
  tv: Tv,
  tablet: Tablet
};

export function DeviceUsageChart({ data }: DeviceUsageChartProps) {
  return (
    <div className="grid grid-cols-2 gap-4 mt-8">
      {data.map((device, index) => {
        const IconComponent = deviceIcons[device.icon as keyof typeof deviceIcons];
        
        return (
          <div className="bg-white p-4 rounded-lg shadow-sm flex items-center" key={index}>
            <div 
              className="w-12 h-12 rounded-full flex items-center justify-center"
              style={{ 
                backgroundColor: `${device.color}/0.1`,
                color: device.color
              }}
            >
              <IconComponent className="text-xl" />
            </div>
            <div className="ml-3">
              <p className="font-medium text-neutral-800">{device.name}</p>
              <p className="text-sm text-neutral-500">{device.percentage}% of time</p>
            </div>
          </div>
        );
      })}
    </div>
  );
}
