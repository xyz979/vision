import { MediaTimeDataItem } from "@/lib/types";

interface MediaTimeChartProps {
  data: MediaTimeDataItem[];
}

export function MediaTimeChart({ data }: MediaTimeChartProps) {
  return (
    <div className="space-y-6 mt-8">
      {data.map((item, index) => (
        <div className="mb-4" key={index}>
          <div className="flex justify-between mb-2">
            <span className="font-medium text-neutral-700">{item.name}</span>
            <span className="font-medium" style={{ color: item.color }}>{item.percentage}%</span>
          </div>
          <div className="h-3 w-full bg-neutral-200 rounded-full overflow-hidden">
            <div 
              className="chart-bar h-full rounded-full transition-all duration-1000 ease-out" 
              style={{ 
                width: `${item.percentage}%`,
                backgroundColor: item.color
              }}
            />
          </div>
        </div>
      ))}
    </div>
  );
}
