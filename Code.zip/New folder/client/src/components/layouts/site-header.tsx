import { Link } from "wouter";
import { Eye } from "lucide-react";

export default function SiteHeader() {
  return (
    <header className="w-full py-4 bg-white shadow-sm">
      <div className="container mx-auto px-4 flex justify-between items-center">
        <Link href="/">
          <a className="flex items-center">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-primary to-accent flex items-center justify-center text-white">
              <Eye className="w-6 h-6" />
            </div>
            <h1 className="ml-3 text-2xl font-display font-bold text-neutral-900">Media<span className="text-primary">Vision</span></h1>
          </a>
        </Link>
        <nav>
          <ul className="flex space-x-6">
            <li><a href="#" className="text-neutral-700 hover:text-primary transition-colors">About</a></li>
            <li><a href="https://mediavision.paperform.co" className="text-neutral-700 hover:text-primary transition-colors">Take Survey</a></li>
            <li><a href="#" className="text-neutral-700 hover:text-primary transition-colors">Contact</a></li>
          </ul>
        </nav>
      </div>
    </header>
  );
}
