import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Download, Share2 } from "lucide-react";

export function ActionSection() {
  const [email, setEmail] = useState("");
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    
    // In a real application, this would send the email to a server
    alert(`Thank you for subscribing with ${email}! You will receive your first recommendations soon.`);
    setEmail("");
  };

  const handleDownload = () => {
    // In a real application, this would generate and download a PDF report
    alert("Report download functionality would be implemented here");
  };

  const handleShare = () => {
    try {
      navigator.clipboard.writeText(window.location.href);
      alert("Profile URL copied to clipboard!");
    } catch (err) {
      console.error("Failed to copy URL: ", err);
    }
  };

  return (
    <section className="py-16 bg-neutral-100">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl font-display font-bold text-neutral-900 mb-6">Enhance Your Media Experience</h2>
          <p className="text-lg text-neutral-600 mb-8">
            Use these insights to make more informed choices about how you consume media. 
            Discover new content aligned with your preferences while exploring beyond your comfort zone.
          </p>
          
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button 
              onClick={handleDownload}
              className="px-6 py-3 bg-primary text-white font-medium rounded-lg shadow-lg hover:bg-primary-dark transition-colors"
            >
              <Download className="w-5 h-5 mr-2" /> Download Full Report
            </Button>
            <Button 
              variant="secondary"
              onClick={handleShare}
              className="px-6 py-3 bg-neutral-800 text-white font-medium rounded-lg shadow-lg hover:bg-neutral-900 transition-colors"
            >
              <Share2 className="w-5 h-5 mr-2" /> Share Your Profile
            </Button>
          </div>
          
          <div className="mt-12 p-6 bg-white rounded-xl shadow-sm">
            <h3 className="text-xl font-display font-semibold mb-4">Want to go deeper?</h3>
            <p className="text-neutral-600 mb-6">
              Get monthly updates with personalized content recommendations based on your evolving preferences.
            </p>
            
            <form className="flex flex-col sm:flex-row gap-3" onSubmit={handleSubmit}>
              <Input
                type="email"
                placeholder="Your email address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="flex-grow px-4 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                required
              />
              <Button 
                type="submit"
                className="px-6 py-2 bg-primary text-white font-medium rounded-lg hover:bg-primary-dark transition-colors"
              >
                Subscribe
              </Button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
