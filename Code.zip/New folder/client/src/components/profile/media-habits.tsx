import { MediaTimeChart } from "@/components/ui/charts/media-time-chart";
import { DeviceUsageChart } from "@/components/ui/charts/device-usage-chart";
import { MediaTimeDataItem, DeviceDataItem } from "@/lib/types";

interface MediaHabitsProps {
  mediaTimeData: MediaTimeDataItem[];
  deviceData: DeviceDataItem[];
}

export function MediaHabits({ mediaTimeData, deviceData }: MediaHabitsProps) {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-3xl font-display font-bold text-neutral-900 mb-3 text-center">Your Media Consumption Habits</h2>
          <p className="text-neutral-600 mb-12 text-center max-w-3xl mx-auto">
            Based on your survey responses, we've analyzed your typical media consumption patterns.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Time Spent Chart */}
            <div className="bg-neutral-100 rounded-xl p-6 shadow-sm">
              <h3 className="text-xl font-display font-semibold mb-4">Time Spent by Medium</h3>
              <MediaTimeChart data={mediaTimeData} />
            </div>
            
            {/* Device Usage */}
            <div className="bg-neutral-100 rounded-xl p-6 shadow-sm">
              <h3 className="text-xl font-display font-semibold mb-4">Primary Devices Used</h3>
              <DeviceUsageChart data={deviceData} />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
