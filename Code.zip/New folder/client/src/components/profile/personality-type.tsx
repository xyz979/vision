import { Film } from "lucide-react";

interface PersonalityTypeProps {
  personalityType: string;
  personalityDescription: string;
  personalityTags: string[];
}

export function PersonalityType({ personalityType, personalityDescription, personalityTags }: PersonalityTypeProps) {
  return (
    <section className="py-16 bg-neutral-100">
      <div className="container mx-auto px-4">
        <div className="max-w-5xl mx-auto">
          <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
            <div className="p-8 md:p-12">
              <div className="flex flex-col md:flex-row items-center md:items-start">
                <div className="w-32 h-32 md:w-40 md:h-40 rounded-[30%_70%_70%_30%/30%_30%_70%_70%] flex-shrink-0 bg-gradient-to-r from-primary to-accent flex items-center justify-center mb-6 md:mb-0">
                  <Film className="text-white w-16 h-16" />
                </div>
                <div className="md:ml-8 text-center md:text-left">
                  <div className="inline-block px-4 py-1 rounded-full bg-secondary-light/10 text-secondary-dark font-medium text-sm mb-4 md:mb-2">
                    Primary Type
                  </div>
                  <h2 className="text-3xl md:text-4xl font-display font-bold text-neutral-900 mb-4">
                    {personalityType}
                  </h2>
                  <p className="text-xl text-neutral-600 mb-6">
                    {personalityDescription}
                  </p>
                  <div className="flex flex-wrap justify-center md:justify-start gap-2">
                    {personalityTags.map((tag, index) => (
                      <span key={index} className="px-3 py-1 rounded-full bg-neutral-200 text-neutral-700 text-sm">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
