import { Insight, Recommendation } from "@/lib/types";
import { Lightbulb, Brain, TrendingUp, Clock } from "lucide-react";

interface InsightsRecommendationsProps {
  insights: Insight[];
  recommendations: Recommendation[];
}

export function InsightsRecommendations({ insights, recommendations }: InsightsRecommendationsProps) {
  // Map of insight icons to Lucide components
  const insightIcons = {
    lightbulb: Lightbulb,
    brain: Brain,
    chart: TrendingUp,
    clock: Clock
  };

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-3xl font-display font-bold text-neutral-900 mb-3 text-center">
            Key Insights & Recommendations
          </h2>
          <p className="text-neutral-600 mb-12 text-center max-w-3xl mx-auto">
            Based on your unique media personality, here are some personalized insights and recommendations.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
            {insights.map((insight, index) => {
              const IconComponent = insightIcons[insight.icon as keyof typeof insightIcons] || Lightbulb;
              
              return (
                <div className="bg-neutral-100 rounded-xl p-6 shadow-sm" key={index}>
                  <div className="flex items-start mb-4">
                    <div 
                      className="w-10 h-10 rounded-full flex items-center justify-center text-white flex-shrink-0"
                      style={{ backgroundColor: insight.color }}
                    >
                      <IconComponent className="w-5 h-5" />
                    </div>
                    <h3 className="ml-3 text-lg font-display font-semibold">{insight.title}</h3>
                  </div>
                  <p className="text-neutral-700">{insight.description}</p>
                </div>
              );
            })}
          </div>
          
          <div className="bg-gradient-to-r from-primary to-accent rounded-2xl shadow-lg overflow-hidden">
            <div className="p-8 text-white">
              <h3 className="text-2xl font-display font-bold mb-4">Personalized Recommendations</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {recommendations.map((rec, index) => (
                  <div className="bg-white/20 backdrop-blur-sm rounded-lg p-4" key={index}>
                    <h4 className="font-medium text-white mb-2">{rec.category}</h4>
                    <ul className="space-y-2">
                      {rec.items.map((item, itemIndex) => (
                        <li className="text-sm" key={itemIndex}>• {item}</li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
