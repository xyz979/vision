import { Button } from "@/components/ui/button";

interface HeroSectionProps {
  profileId: string;
}

export function HeroSection({ profileId }: HeroSectionProps) {
  const handleShare = () => {
    try {
      navigator.clipboard.writeText(window.location.href);
      // Could use toast notification here
      alert("Profile URL copied to clipboard!");
    } catch (err) {
      console.error("Failed to copy URL: ", err);
    }
  };

  return (
    <section className="py-12 md:py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-block px-3 py-1 rounded-full bg-primary-light/10 text-primary-dark font-medium text-sm mb-6">
            Results Ready
          </div>
          <h1 className="text-4xl md:text-5xl font-display font-bold text-neutral-900 mb-6">Your Media Personality Profile</h1>
          <p className="text-xl text-neutral-600 mb-8">
            Based on your responses, we've created a personalized analysis of your media consumption habits and preferences.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button 
              onClick={handleShare} 
              className="px-6 py-3 bg-primary text-white font-medium rounded-lg shadow-lg hover:bg-primary-dark transition-colors"
            >
              Share Results
            </Button>
            <Button 
              variant="outline"
              onClick={() => window.location.href = "https://mediavision.paperform.co"}
              className="px-6 py-3 bg-white text-primary border border-primary font-medium rounded-lg hover:bg-primary/5 transition-colors"
            >
              Take Another Survey
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
