import { ContentPreference } from "@/lib/types";
import { Film, Music, Share } from "lucide-react";

interface ContentPreferencesProps {
  contentPreferences: ContentPreference[];
}

export function ContentPreferences({ contentPreferences }: ContentPreferencesProps) {
  // Map of preference types to icons
  const preferenceIcons = {
    film: Film,
    music: Music,
    share: Share
  };

  return (
    <section className="py-16 bg-neutral-100">
      <div className="container mx-auto px-4">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-3xl font-display font-bold text-neutral-900 mb-3 text-center">
            Your Content Preferences
          </h2>
          <p className="text-neutral-600 mb-12 text-center max-w-3xl mx-auto">
            Your survey responses reveal your unique preferences across different media types.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {contentPreferences.map((preference, index) => {
              const IconComponent = preferenceIcons[preference.icon as keyof typeof preferenceIcons];
              
              return (
                <div className="bg-white rounded-xl shadow-sm overflow-hidden" key={index}>
                  <div className="h-2" style={{ backgroundColor: preference.color }}></div>
                  <div className="p-6">
                    <div className="flex items-center mb-4">
                      <div 
                        className="w-10 h-10 rounded-full flex items-center justify-center"
                        style={{ 
                          backgroundColor: preference.colorLight,
                          color: preference.color
                        }}
                      >
                        <IconComponent className="w-5 h-5" />
                      </div>
                      <h3 className="ml-3 text-lg font-display font-semibold">{preference.type}</h3>
                    </div>
                    
                    <div className="space-y-4">
                      <div>
                        <h4 className="text-sm font-medium text-neutral-500 mb-2">Favorite Genres</h4>
                        <div className="flex flex-wrap gap-2">
                          {preference.favoriteGenres.map((genre, genreIndex) => (
                            <span 
                              key={genreIndex} 
                              className="px-2 py-1 text-xs rounded-full"
                              style={{ 
                                backgroundColor: preference.colorLight,
                                color: preference.color.replace('/0.1', '-dark')
                              }}
                            >
                              {genre}
                            </span>
                          ))}
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="text-sm font-medium text-neutral-500 mb-2">
                          {preference.type === "Social Media" ? "Usage Pattern" : 
                           preference.type === "Music" ? "Listening Habits" : 
                           "Viewing Habits"}
                        </h4>
                        <p className="text-sm text-neutral-700">{preference.habits}</p>
                      </div>
                      
                      <div>
                        <h4 className="text-sm font-medium text-neutral-500 mb-2">Notable Insight</h4>
                        <p className="text-sm text-neutral-700">{preference.insight}</p>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
