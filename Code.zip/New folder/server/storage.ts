import { 
  users, type User, type InsertUser,
  mediaProfiles, type MediaProfile, type InsertMediaProfile,
  surveySubmissions, type SurveySubmission, type InsertSurveySubmission
} from "@shared/schema";
import { nanoid } from "nanoid";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Media profile methods
  getMediaProfile(profileId: string): Promise<MediaProfile | undefined>;
  createMediaProfile(profile: InsertMediaProfile): Promise<MediaProfile>;
  
  // Survey submission methods
  getSurveySubmission(submissionId: string): Promise<SurveySubmission | undefined>;
  createSurveySubmission(submission: InsertSurveySubmission): Promise<SurveySubmission>;
  markSurveySubmissionProcessed(submissionId: string, profileId: string): Promise<SurveySubmission | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private mediaProfiles: Map<string, MediaProfile>;
  private surveySubmissions: Map<string, SurveySubmission>;
  currentUserId: number;

  constructor() {
    this.users = new Map();
    this.mediaProfiles = new Map();
    this.surveySubmissions = new Map();
    this.currentUserId = 1;
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Media profile methods
  async getMediaProfile(profileId: string): Promise<MediaProfile | undefined> {
    return this.mediaProfiles.get(profileId);
  }
  
  async createMediaProfile(profile: InsertMediaProfile): Promise<MediaProfile> {
    const now = new Date();
    const mediaProfile: MediaProfile = { 
      ...profile, 
      id: this.mediaProfiles.size + 1,
      createdAt: now
    };
    this.mediaProfiles.set(profile.profileId, mediaProfile);
    return mediaProfile;
  }
  
  // Survey submission methods
  async getSurveySubmission(submissionId: string): Promise<SurveySubmission | undefined> {
    return this.surveySubmissions.get(submissionId);
  }
  
  async createSurveySubmission(submission: InsertSurveySubmission): Promise<SurveySubmission> {
    const now = new Date();
    const surveySubmission: SurveySubmission = { 
      ...submission, 
      id: this.surveySubmissions.size + 1,
      processed: false,
      profileId: null,
      createdAt: now
    };
    this.surveySubmissions.set(submission.submissionId, surveySubmission);
    return surveySubmission;
  }
  
  async markSurveySubmissionProcessed(submissionId: string, profileId: string): Promise<SurveySubmission | undefined> {
    const submission = this.surveySubmissions.get(submissionId);
    if (!submission) return undefined;
    
    const updatedSubmission: SurveySubmission = {
      ...submission,
      processed: true,
      profileId
    };
    
    this.surveySubmissions.set(submissionId, updatedSubmission);
    return updatedSubmission;
  }
}

export const storage = new MemStorage();
