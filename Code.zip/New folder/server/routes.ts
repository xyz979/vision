import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { nanoid } from "nanoid";
import { 
  paperformWebhookSchema, 
  insertSurveySubmissionSchema, 
  insertMediaProfileSchema 
} from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";
import { analyzeMediaProfile } from "../client/src/lib/utils/analyse-media-profile";

export async function registerRoutes(app: Express): Promise<Server> {
  // API endpoints
  // Webhook endpoint to receive Paperform data
  app.post("/api/webhook/paperform", async (req: Request, res: Response) => {
    try {
      // Validate webhook payload
      const webhookData = paperformWebhookSchema.parse(req.body);
      
      // Create survey submission record
      const submissionDate = new Date(webhookData.submitted_at);
      const submission = await storage.createSurveySubmission({
        submissionId: webhookData.submission_id,
        formId: webhookData.form_id,
        formName: webhookData.form_name,
        submittedAt: submissionDate,
        formData: webhookData.data
      });
      
      // Process survey data to generate media profile
      const profileId = nanoid();
      const profileData = analyzeMediaProfile(webhookData.data);
      
      // Create media profile record
      const mediaProfile = await storage.createMediaProfile({
        userId: null,
        profileId,
        surveyData: webhookData.data,
        ...profileData
      });
      
      // Mark survey as processed
      await storage.markSurveySubmissionProcessed(
        webhookData.submission_id,
        profileId
      );
      
      res.status(200).json({ 
        success: true, 
        message: "Webhook received and processed",
        profileId
      });
    } catch (error) {
      console.error("Webhook processing error:", error);
      
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        res.status(400).json({ 
          success: false, 
          message: "Invalid webhook payload",
          error: validationError.message
        });
      } else {
        res.status(500).json({ 
          success: false, 
          message: "Error processing webhook data",
          error: error instanceof Error ? error.message : "Unknown error"
        });
      }
    }
  });
  
  // Get media profile by ID
  app.get("/api/profile/:profileId", async (req: Request, res: Response) => {
    try {
      const { profileId } = req.params;
      const profile = await storage.getMediaProfile(profileId);
      
      if (!profile) {
        return res.status(404).json({ 
          success: false, 
          message: "Profile not found" 
        });
      }
      
      res.status(200).json(profile);
    } catch (error) {
      console.error("Error fetching profile:", error);
      res.status(500).json({ 
        success: false, 
        message: "Error fetching profile",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
