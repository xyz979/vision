import { pgTable, text, serial, integer, boolean, jsonb, timestamp, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Media personality profile schema
export const mediaProfiles = pgTable("media_profiles", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  profileId: varchar("profile_id", { length: 64 }).notNull().unique(),
  surveyData: jsonb("survey_data").notNull(),
  personalityType: text("personality_type").notNull(),
  personalityDescription: text("personality_description").notNull(),
  mediaTimeData: jsonb("media_time_data").notNull(),
  deviceData: jsonb("device_data").notNull(),
  contentPreferences: jsonb("content_preferences").notNull(),
  insights: jsonb("insights").notNull(),
  recommendations: jsonb("recommendations").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertMediaProfileSchema = createInsertSchema(mediaProfiles).omit({
  id: true,
  createdAt: true,
});

export type InsertMediaProfile = z.infer<typeof insertMediaProfileSchema>;
export type MediaProfile = typeof mediaProfiles.$inferSelect;

// Survey submission schema
export const surveySubmissions = pgTable("survey_submissions", {
  id: serial("id").primaryKey(),
  submissionId: varchar("submission_id", { length: 64 }).notNull().unique(),
  formId: varchar("form_id", { length: 64 }).notNull(),
  formName: text("form_name").notNull(),
  submittedAt: timestamp("submitted_at").notNull(),
  formData: jsonb("form_data").notNull(),
  processed: boolean("processed").default(false).notNull(),
  profileId: varchar("profile_id", { length: 64 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertSurveySubmissionSchema = createInsertSchema(surveySubmissions).omit({
  id: true,
  processed: true,
  profileId: true,
  createdAt: true,
});

export type InsertSurveySubmission = z.infer<typeof insertSurveySubmissionSchema>;
export type SurveySubmission = typeof surveySubmissions.$inferSelect;

// Define type for Paperform webhook payload
export const paperformWebhookSchema = z.object({
  form_id: z.string(),
  form_name: z.string(),
  submission_id: z.string(),
  submitted_at: z.string(),
  data: z.record(z.unknown())
});

export type PaperformWebhook = z.infer<typeof paperformWebhookSchema>;
